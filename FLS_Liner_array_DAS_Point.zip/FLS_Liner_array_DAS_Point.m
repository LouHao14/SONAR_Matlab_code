clear all; close all;
addpath(genpath("./ustb"))
addpath(genpath("./Field_II"))
% addpath(genpath("./Lib"))
%% 基本常量
c0 = 1500;
fs = 10e6;
dt = 1/fs;

field_init(0);
set_field('c',c0);
set_field('fs',fs);
set_field('use_rectangles',1);

% 探头参数，线阵，x轴放置，z为前视方向
probe = uff.linear_array();
f0                      = 0.9e+06;      % Transducer center frequency [Hz]
lambda                  = c0/f0;           % Wavelength [m]
probe.element_height    = 15e-3;            % Height of element [m]
probe.pitch             = lambda;        % probe.pitch [m]
kerf                    = 0.1*lambda;        % gap between elements [m]
probe.element_width     = probe.pitch-kerf;% Width of element [m]
% lens_el                 = 20e-3;           % position of the elevation focus
probe.N                 = 128;             % Number of elements
pulse_duration          = 2.5;             % pulse duration [cycles]

%% ═══════════════════════ 用户参数 ═══════════════════════════════════════
stl_file    = '.\ball.stl';              % STL 模型
stl_scale   = 0.05;                     % 🔶 比例因子 0.5=缩小一半
stl_pos     = [2 8 6];                % 📌 放置位置 (x ,z ,y[depth])，注意 y 被用于 depth
stl_rot_deg = [0 0 90];               % [roll pitch yaw]°

seabed_len  = 15;  seabed_wid = 15;    % 📌 z×x 尺寸   m
seabed_y0   = 10;  seabed_amp = 3;     % 📌 平均深度 / 起伏（depth 在 y 方向）
N_seabed_scatter = 1e4;                % 海底散射点数

FOV_yaw   = -45:1:45;                  % 🔶 水平角网格 41 条
FOV_pitch = -45:1:45;                  % 🔶 俯仰角网格 31 条
FOV_R     = seabed_len;                % 射线长度

%% ═══════════════════════ ① STL 处理 ════════════════════════════════════
try
    TR = stlread(stl_file); stl_V = TR.Points;
catch
    [~, stl_V] = stlread(stl_file);
end
%%
[stl_V, ~, idxFaces] = unique(stl_V, 'rows');   % ~ 去重后点数可能更小

%%
voxel = 0.4;               % 体素边长（与 STL 单位同量级）
minCoord = floor(min(stl_V)/voxel);
idx = round((stl_V - minCoord*voxel)/voxel);   % 映射到体素索引

[~, firstIdx] = unique(idx, 'rows', 'stable');
stl_V = stl_V(firstIdx, :);
%%

stl_V = stl_scale * stl_V;             % 🔶 缩放
r = stl_rot_deg;
Rxm = [1 0 0;0 cosd(r(1)) -sind(r(1));0 sind(r(1)) cosd(r(1))];
Rym = [cosd(r(2)) 0 sind(r(2));0 1 0;-sind(r(2)) 0 cosd(r(2))];
Rzm = [cosd(r(3)) -sind(r(3)) 0;sind(r(3)) cosd(r(3)) 0;0 0 1];
Rot  = Rzm*Rym*Rxm;

% 📌 变换并重排为 (x, y[depth], z)
pos_target = (Rot * stl_V.').' + stl_pos;  % 原为 Nx3 的 [x z y]
pos_target = pos_target(:, [1 3 2]);       % 改为 [x y z]，其中 y 为 depth


%% ═══════════════════════ ② 海底散射体生成（以 y 为深度） ════════════════
Nx = round( sqrt(N_seabed_scatter * seabed_wid / seabed_len) );
Nz = round( N_seabed_scatter / Nx );

x_lin = linspace(-seabed_wid/2, seabed_wid/2, Nx);   % 横向 x
z_lin = linspace(0, seabed_len, Nz);                % 纵向 z（“前方”）
[Xg,Zg] = meshgrid(x_lin, z_lin);

Yg = seabed_y0 + seabed_amp * ( ...
      0.5*sin(2*pi*Xg/seabed_wid) + 0.5*sin(2*pi*Zg/seabed_len) ) + ...
      0.1*randn(size(Xg));  % 📌 y 方向作为深度，加入扰动

% 📌 散射点为 [x, y[depth], z]
pos_seabed = [Xg(:) Yg(:) Zg(:)];


amp_target = 0.23*ones(size(pos_target,1),1);
amp_seabed = 0.2 * abs(randn(size(pos_seabed,1),1));
%% ═══════════════════════ ③ 场景预览 (3-D + 两视图 + 网格) ══════════════
figure('Name','FLS Scene Preview','Position',[50 60 1400 700]);

% --- 3-D ---------------------------------------------------------------
subplot(2,3,1);
scatter3(pos_seabed(:,1),pos_seabed(:,2),pos_seabed(:,3),3,'b.'); hold on;
scatter3(pos_target(:,1),pos_target(:,2),pos_target(:,3),10,'g','filled');
plot3(0,0,0,'rp','MarkerFaceColor','r','MarkerSize',10);
set(gca,'ZDir','reverse'); axis equal tight; grid on;
xlabel('x');ylabel('y');zlabel('z'); title('3-D');
view(35,25);

% --- 顶视 (x-y) --------------------------------------------------------
subplot(2,3,2);
scatter(pos_seabed(:,1),pos_seabed(:,2),3,'b.'); hold on;
scatter(pos_target(:,1),pos_target(:,2),10,'g','filled');
plot(0,0,'rp','MarkerFaceColor','r','MarkerSize',8);   
axis equal tight; grid on; xlabel('x');ylabel('y'); title('Top x-y');

% --- 侧视 (y-z) --------------------------------------------------------
subplot(2,3,3);
scatter(pos_seabed(:,2),pos_seabed(:,3),3,'b.'); hold on;
scatter(pos_target(:,2),pos_target(:,3),10,'g','filled');
plot(0,0,'rp','MarkerFaceColor','r','MarkerSize',8);   
set(gca,'YDir','reverse'); axis equal tight; grid on;
xlabel('y');ylabel('z'); title('Side y-z');

% --- FOV 网格 ----------------------------------------------------------
subplot(2,3,[4 5 6]); hold on; axis equal; grid on;
set(gca,'ZDir','reverse'); xlabel('x');ylabel('y');zlabel('z');
title('FOV Grid & Scatterers');

% 水平网格 (pitch=0)
for ya = FOV_yaw
    dir = [ sind(ya)  cosd(ya)  0 ] * FOV_R;
    plot3([0 dir(1)],[0 0],[0 dir(2)],'b-');
end
% 垂直网格 (yaw=0)
for pa = FOV_pitch
    dir = [ 0  cosd(pa)  sind(pa)] * FOV_R;
    plot3([0 dir(1)],[0 dir(3)],[0 dir(2)],'r-');
end
% 绘制稀疏海底和目标
scatter3(pos_seabed(1:15:end,1),pos_seabed(1:15:end,2), ...
         pos_seabed(1:15:end,3),3,'b.');
scatter3(pos_target(:,1),pos_target(:,2),pos_target(:,3),10,'g','filled');
plot3(0,0,0,'rp','MarkerFaceColor','r','MarkerSize',10);
legend('Yaw grid','Pitch grid','scatterers','target','array','Location','best');
view(3);
drawnow;


%% 激励脉冲
pulse = uff.pulse();
pulse.fractional_bandwidth = 1/9;        % probe bandwidth [1]
pulse.center_frequency = f0;
BW=pulse.fractional_bandwidth*f0; 
pulse_len=2e-3; 

Tx = xdc_piston(0.25*lambda,0.25*lambda/4);

t0 = (-1/pulse.fractional_bandwidth/f0): dt : (1/pulse.fractional_bandwidth/f0);
impulse_response = 1;
t_p=0:1/fs:pulse_len;
excitation = chirp(t_p,f0-BW/2,pulse_len,f0+BW/2).*hamming(numel(t_p))';
excitation = excitation-mean(excitation); % To get rid of DC
one_way_ir = conv(impulse_response,excitation);
MF = conj(flipud(excitation(:)));                  % FIR 形式
two_way_ir = conv(one_way_ir,MF);
lag = length(two_way_ir)/2+1;   
% We display the pulse to check that the lag estimation is on place 
% (and that the pulse is symmetric)
figure;
plot((0:(length(two_way_ir)-1))*dt -lag*dt,two_way_ir); hold on; grid on; axis tight
plot((0:(length(two_way_ir)-1))*dt -lag*dt,abs(hilbert(two_way_ir)),'r')
plot([0 0],[min(two_way_ir) max(two_way_ir)],'g');
legend('2-ways pulse','Envelope','Estimated lag');
title('2-ways impulse response Field II');

% 构建aperture
noSubAz=round(probe.element_width/(lambda/8));        % number of subelements in the azimuth direction
noSubEl=round(probe.element_height/(lambda/8));       % number of subelements in the elevation direction
Th = xdc_linear_array (probe.N, probe.element_width, probe.element_height, kerf, noSubAz, noSubEl, [0 0 Inf]); 

% Th = xdc_piston(lambda/80, lambda/800);
Rh = xdc_linear_array (probe.N, probe.element_width, probe.element_height, kerf, noSubAz, noSubEl, [0 0 Inf]); 

% We also set the excitation, impulse response and baffle as below:
xdc_excitation (Th, excitation);
xdc_impulse (Th, impulse_response);
xdc_baffle(Th, 0);
xdc_center_focus(Th,[0 0 0]);
xdc_impulse (Rh, impulse_response);
xdc_baffle(Rh, 0);
xdc_center_focus(Rh,[0 0 0]);
%% Define plane wave sequence
F_number = 1;
alpha_max = 0;
Na=1;                                      % number of plane waves 
F=1;                                        % number of frames
alpha=linspace(-alpha_max,alpha_max,Na);    % vector of angles [rad]
%% Define phantom
point_position=[pos_target;pos_seabed]; point_amplitudes=[amp_target;amp_seabed];
%% output data
cropat=round(2*50e-3/c0/dt);    % maximum time sample, samples after this will be dumped
CPW=zeros(cropat,probe.N,1,1);  % impulse response channel data
%% Compute CPW signals
time_index=0;
disp('Field II: Computing CPW dataset');
wb = waitbar(0, 'Field II: Computing Forward Looking MBES dataset');
win = blackman(probe.N);
for f=1:F
    waitbar(0, wb, sprintf('Field II: Computing CPW dataset, frame %d',f));
    for n=1:Na
        waitbar(n/Na, wb);
        disp(['Calculating angle ',num2str(n),' of ',num2str(Na)]);
         
        % transmit aperture
        tmp = zeros(1,probe.N/2);
        xdc_apodization(Th,0,[tmp(1:end-1),1,1,tmp(1:end-1)]);
        xdc_times_focus(Th,0,probe.geometry(:,1)'.*sin(alpha(n))/c0);
        
        % receive aperture
        xdc_apodization(Rh, 0, ones(1,probe.N));
        xdc_focus_times(Rh, 0, zeros(1,probe.N));

        % do calculation
        [v,t]=calc_scat_multi(Th, Rh, point_position, point_amplitudes);

        % Match Filter

        sig_mf = zeros(size(v));
        for m = 1:probe.N
            tmp = conv(v(:,m), MF, 'same');
            sig_mf(:,m) = tmp*win(m);
        end
        % build the dataset
        CPW(1:size(v,1),:,n,f)=sig_mf;
        
        %
        clear sig_mf tmp
        % Save transmit sequence
        seq(n)=uff.wave();
        seq(n).probe=probe;
        % seq(n).source.azimuth=alpha(n);
        seq(n).source.distance=Inf;
        seq(n).sound_speed=c0;
        seq(n).delay = -lag*dt+t;
    end
end
close(wb);
%% Channel Data
% 
% In this part of the code, we creat a uff data structure to specifically
% store the captured ultrasound channel data.
channel_data = uff.channel_data();
channel_data.sampling_frequency = fs;
channel_data.sound_speed = c0;
channel_data.initial_time = 0;
channel_data.pulse = pulse;
channel_data.probe = probe;
channel_data.sequence = seq;
channel_data.data = CPW./max(CPW(:));

%% Create Sector scan
depth_axis=linspace(0e0,25e0,512).';
azimuth_axis=linspace(-45,45,451)/180*pi;


sca=uff.sector_scan('azimuth_axis',azimuth_axis,'depth_axis',depth_axis);
%% Pipeline
%
% With *channel_data* and a *scan* we have all we need to produce an
% ultrasound image. We now use a USTB structure *pipeline*, that takes an
% *apodization* structure in addition to the *channel_data* and *scan*.

pipe=pipeline();
pipe.channel_data=channel_data;
pipe.scan=sca;

pipe.receive_apodization.window=uff.window.tukey25;
pipe.receive_apodization.f_number=F_number;

%% 
%
% The *pipeline* structure allows you to implement different beamformers 
% by combination of multiple built-in *processes*. By changing the *process*
% chain other beamforming sequences can be implemented. It returns yet 
% another *UFF* structure: *beamformed_data*.
% 
% To achieve the goal of this example, we use delay-and-sum (implemented in 
% the *das_mex()* process) as well as coherent compounding.

b_data=pipe.go({midprocess.das()});% postprocess.coherent_compounding()});

% Display images
b_data.plot();
colormap(hot); colorbar; caxis([-70 0]);

